package Valuable;

public class Valuable{
//	public static void main(String[] args) {
//	 int SPEED = 20;
//		int count = 10;
//		SPEED = 40;
//		count = 11;
//		System.out.print("상수 SPEED 값은 ");
//		System.out.println("SPEED");
//		System.out.print("변수 count 값은 ");
//		System.out.println("count");
//	}
//}
	public static void main(String[] args) {
		String greeting = "Welcome to Shopping mall";
		String tagline = "Welcome to  Book Market";
	
		System.out.println("***********************");
		System.out.println("\t"+greeting);//tab 만큼 공백을 두고 greeting 변수의 문자열 출력
		System.out.println("\t"+tagline);//tab 만큼 공백을 두고 tagline 변수의 문자열 출력
		System.out.println("***********************");
		System.out.println("1. 고객 정보 확인하기 \t5. 바구니에 항목 추가하기");
		System.out.println("2. 장바구니 상품 목록 보기 \t6. 장바구니의 항목 수량 줄이기");
		System.out.println("3. 장바구니 비우기 \t7. 장바구니의 항목 삭제하기");
		System.out.println("4. 영수증 표시하기 \t8. 종료");
		System.out.println("***********************");
	
		
	}
}
